#include<stdio.h>

// 1
//int main()
//{
//	int num = 1;
//	unsigned int positiveNumber = 7676;
//	double doubleNumber = 8.99898;
//	char chariito = 'c';
//
//	printf("%c\n", chariito);
//	printf("%d\n", positiveNumber);
//	printf("%u\n", positiveNumber);
//	printf("%lf", doubleNumber);
//	return 0;
//	
//}