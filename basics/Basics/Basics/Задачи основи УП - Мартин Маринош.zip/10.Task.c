#include<stdio.h>
#include<math.h>
//
//int main()
//{
//	int numberOne;
//	int numberTwo;
//
//	scanf_s("%d", &numberOne);
//	scanf_s("%d", &numberTwo);
//
//	int sum = (numberOne * numberOne * numberOne) + (numberTwo * numberTwo * numberTwo);
//	//int sum2 = (int)pow(numberOne, 3) + (int)pow(numberTwo, 3); 
//
//	printf("%d", sum);
//	//printf("%d", sum2);
//	return 0;
//}