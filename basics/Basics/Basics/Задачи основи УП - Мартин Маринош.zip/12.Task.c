#include<stdio.h>
#include<math.h>

//int main()
//{
//	const int x0 = 0;
//	const int y0 = 0;
//
//	double x;
//	double y;
//	
//	printf("Insert x and y: ");
//	scanf_s("%lf %lf", &x, &y);
//
//	double distance = sqrt(pow(x - x0, 2) + pow(y - y0, 2));
//
//	printf("%0.2lf", distance);
// 
//  return 0;
//}