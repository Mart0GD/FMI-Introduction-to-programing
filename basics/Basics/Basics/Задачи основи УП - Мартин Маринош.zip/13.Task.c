#include<stdio.h>

//int main()
//{
//	const int leapYearFirstCriteria = 4;
//	const int leapYearSecondCriteria = 100;
//	const int leapYearThirdCriteria = 400;
//
//	int year;
//
//	scanf_s("%d", &year);
//
//	int isLeapYear = (year % leapYearFirstCriteria == 0 && year % leapYearSecondCriteria != 0) || year % leapYearThirdCriteria == 0;
//
//	printf("%d", isLeapYear);
// 
//  return 0;
//}