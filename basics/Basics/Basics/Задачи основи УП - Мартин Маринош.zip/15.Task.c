#include<stdio.h>
#include<math.h>

//int main()
//{
//	int a = 0;
//	int b = 0;
//
//	scanf_s("%d %d", &a, &b);
//
//	a = a + b;
//	b = a - b;
//	a = a - b;
//
//	return 0;
//}