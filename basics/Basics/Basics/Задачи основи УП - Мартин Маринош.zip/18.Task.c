#include<stdio.h>

//int main()
//{
//	int x, y;
//	scanf_s("%d %d", &x, &y);
//
//	int quadrant = 0; // default is 0,0
//
//
//	quadrant += (x > 0 && y > 0);
//	quadrant += ((x < 0 && y > 0) * 2);
//	quadrant += ((x < 0 && y < 0) * 3);
//	quadrant += ((x > 0 && y < 0) * 4);
//
//	printf("%d", quadrant);
//
//	return 0;
//}