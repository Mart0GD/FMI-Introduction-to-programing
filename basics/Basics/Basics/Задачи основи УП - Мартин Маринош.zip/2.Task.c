#include<stdio.h>



// 2 
//int main()
//{
//	int intNumber;
//	unsigned int positiveInt;
//	double fpNumber;
//	char smt;
//
//	//printf("Please insert an intiger value:");
//	scanf_s("%d %u %lf %c", &intNumber, &positiveInt, &fpNumber, &smt);
//
//	////printf("Please insert an positive intiger value:");
//	//scanf_s("%u", &positiveInt);
//
//	////printf("Please insert an floating point number value:");
//	//scanf_s("%lf", &fpNumber);
//
//	////printf("Please insert a character value:");
//	//scanf_s("%c", &smt);
//
//	printf("%d\n", intNumber);
//	printf("%u\n", positiveInt);
//	printf("%lf\n", fpNumber);
//	printf("%c\n", smt);
//
//
//
//	return 0;
//}


