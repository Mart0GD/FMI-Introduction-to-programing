#include<stdio.h>

//int main() {
//
//	int a;
//	int b;
//
//	scanf_s("%d", &a);
//	scanf_s("%d", &b);
//
//	printf("%d\n", a + b);
//	printf("%d\n", a - b);
//	printf("%d\n", a * b);
//	printf("%d\n", a / b);
//	printf("%d\n", a % b);
//	printf("%d\n", a < b);
//	printf("%d\n", a > b);
//	printf("%d\n", a == b);
//	printf("%d\n", a <= b);
//	printf("%d\n", a >= b);
//	printf("%d\n", a != b);
//	return 0;
//}