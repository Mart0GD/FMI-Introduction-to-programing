#include<stdio.h>

// 4
//int main()
//{
//	int numberOne;
//	int numberTwo;
//	int numberThree;
//
//	printf("Enter number one:\n");
//	scanf_s("%d", &numberOne);
//
//	printf("Enter number two:\n");
//	scanf_s("%d", &numberTwo);
//
//	printf("Enter number three:\n");
//	scanf_s("%d", &numberThree);
//	
//	float sum = (numberOne + numberTwo + numberThree) / 3.0;
//
//	printf("Average:\n");
//	printf("%f", sum);
//	
//	return 0;
//}