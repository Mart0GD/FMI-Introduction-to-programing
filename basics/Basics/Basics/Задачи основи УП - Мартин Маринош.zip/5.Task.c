#include<stdio.h>

//int main()
//{
//	const double pi = 3.14;
//
//	int radius;
//
//	scanf_s("%d", &radius);
//	double area = pi * (radius * radius);
//
//	printf("%lf", area);
//
//	return 0;
//}