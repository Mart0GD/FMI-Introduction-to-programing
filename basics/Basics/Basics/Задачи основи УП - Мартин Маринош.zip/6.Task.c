#include<stdio.h>
//
//int main()
//{
//	char character;
//
//	scanf_s("%c", &character);
//
//	char characterLowercase = (char)(character + 32);
//	printf("%c", characterLowercase);
//
//	return 0;
//}