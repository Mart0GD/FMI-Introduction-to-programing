#include<stdio.h>
//
//int main()
//{
//	int number;
//
//	scanf_s("%d", &number);
//
//	printf("%d", number > 99 && number <= 999);
//
//	return 0;
//}