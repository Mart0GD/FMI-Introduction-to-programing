#include<stdio.h>
//
//int main()
//{
//	int number;
//
//	scanf_s("%d", &number);
//	printf("%d", number % 10);
//
//	return 0;
//}