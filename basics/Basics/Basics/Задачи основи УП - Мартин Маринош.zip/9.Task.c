#include<stdio.h>
#include<math.h>

//int main() {
//	double number;
//
//	scanf_s("%lf", &number);
//	printf("%.3lf", number);
//	return 0;
//}